module.exports = {
  i18n: {
    locales: ["en", "bg"],
    defaultLocale: "en",
    localeDetection: false,
  },
};
