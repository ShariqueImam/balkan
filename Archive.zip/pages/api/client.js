import client from '@sanity/client';
export default client({
    projectId: '02r9lx8e',
    dataset: 'production',
})