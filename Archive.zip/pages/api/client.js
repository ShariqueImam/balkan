import client from '@sanity/client';
export default client({
    projectId: 'so6le7q1',
    dataset: 'production',
})